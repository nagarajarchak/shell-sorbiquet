BASH_RC_FILE_NAME = ".bash_profile"
BASH_ALIAS_FILE_NAME = ".shell-sobriquet-aliases.sh"
LIST = "ls"
CLEAR = "clear"